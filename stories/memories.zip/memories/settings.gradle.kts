rootProject.name = "memories"
