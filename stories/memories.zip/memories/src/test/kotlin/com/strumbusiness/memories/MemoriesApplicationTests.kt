package com.strumbusiness.memories

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MemoriesApplicationTests {

	@Test
	fun contextLoads() {
	}

}
